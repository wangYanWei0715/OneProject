

| 名称                       | 版本号        | 开源协议               |
| -------------------------- | ------------- | ---------------------- |
| moleculer                  | 0.14.31       | MIT license            |
| moleculer-registry         | 0.14.21       | MIT license            |
| moleculer-web              | 0.10.5        | MIT license            |
| moleculer-apollo-server    | 0.3.6         | MIT license            |
| express                    | 4.18.2        | MIT license            |
| moleculer-transporter      | 0.14.21       | MIT license            |
| Log4js                     | 6.6.0         | Apache 2.0 License     |
| moleculer-graphql          | 0.0.1         | MIT license            |
| moleculer-io               | 2.0.0         | MIT license            |
| moleculer-protect-services | 1.0.0         | MIT license            |
| oauth-moleculer            | 1.2.0         | MIT license            |
| cobra                      | 1.6.1         | Apache-2.0 license     |
| zerolog                    | 1.29.0        | MIT license            |
| Containerd                 | 1.6.17        | Apache-2.0 license     |
| CNI                        | v1.1.1        | Apache-2.0 license     |
| JWT                        | 4.5.0         | MIT License            |
| Gin                        | 1.8.2         | MIT License            |
| gorm                       | 1.24.2        | MIT License            |
| ssh                        | 0.3.5         | MIT License            |
| sshpass                    | 1.0.6         | MIT License            |
| prisma                     | 3.14.0        | Apache License         |
| body-parser                | 1.20.0        | MIT license            |
| compression                | 2.9.1         | MIT license            |
| cookie-parser              | 1.4.6         | MIT license            |
| cookie-session             | 2.0.0         | MIT license            |
| morgan                     | 1.10.0        | Apache License         |
| cors                       | 2.8.5         | MIT License            |
| apollo-server              | 3.10.0        | MIT License            |
| form-generator             | 0.2.0         | MIT license            |
| imove                      | 0.4           | MIT license            |
| maven                      | 3.6           | Apache-2.0 license     |
| JDK8                       | 1.8.0(8u201)  | GPL-2.0 license        |
| Jackson                    | 2.13.0        | 无                     |
| Apache Commons             |               | Apache-2.0 license     |
| log4j                      | 2.18.0        | Apache-2.0 license     |
| slf4j                      | 1.7.36        | MIT license            |
| Protobuf                   | 3.15.6        | BSD 3-Clause License   |
| libcurl                    | 7.70.0        | MIT/X derivate license |
| rapidjson                  | 1.1.0         | MIT License            |
| springboot                 | 2.7.1         | Apache License 2.0     |
| mybatis-plus               | 3             | Apache License 2.0     |
| Easy Excel                 | 3.1.1         | Apache License 2.0     |
| hutool                     | 5.8.4         | 木兰宽松许可证, 第2版  |
| guava                      | 31.1          | Apache License 2.0     |
| mockito                    | 4.6.1         | MIT License            |
| OPC UA SDK                 | 1.4.2         | 无                     |
| ACE_wrappers               | 6.3.2         | 无                     |
| SQLite                     | 3.39.1        | Publish Domain         |
| libiconv                   | 1.11.1        | LGPL                   |
| LibXML2                    | 2.7.8         | MIT License            |
| net-snmp                   | 5.4.2.1       | BSD                    |
| jsPlumb                    | 2.15.5        | MIT License            |
| openssl                    | 1.0.1g        | BSD-style              |
| InfluxDB                   | 2.1           | MIT                    |
| glusterfs                  | 10.1          | Activity               |
| postgreSQL                 | 14.8          | BSD                    |
| keepalived                 | 2.2           | VRRP                   |
| chronyd                    | 3.5           | GPLv2                  |
| JsonCpp                    | 1.9.5         | MIT                    |
| casbin                     | 5.28.0        | Apache License 2.0     |
| redis                      | 6.2.11        | BSD 3-Clause License   |
| icu                        | 70.1          | Unicode License        |
| jmalloc                    | 5.3.0         | BSD 2-Clause License   |
| axios                      | 1.3.4         | MIT                    |
| axios                      | 1.2.0         | MIT                    |
| axios                      | 1.4.0         | MIT                    |
| element-plus               | 2.3.14        | MIT                    |
| element-plus               | 2.7.0         | MIT                    |
| element-plus               | 2.3.8         | MIT                    |
| element-plus               | 2.3.12        | MIT                    |
| element-plus               | 2.2.29        | MIT                    |
| element-plus               | 2.7.2         | MIT                    |
| element-plus               | 2.3.14        | MIT                    |
| element-plus               | 2.3.5         | MIT                    |
| pinia                      | 2.0.32        | MIT                    |
| pinia                      | 2.0.30        | MIT                    |
| graphql                    | 16.6.0        | MIT                    |
| @apollo/client             | 3.7.10        | MIT                    |
| vue                        | 3.2.45        | MIT                    |
| vue                        | 3.3.4         | MIT                    |
| vue-router                 | 4.1.6         | MIT                    |
| echarts                    | 5.4.2         | Apache-2.0             |
| echarts                    | 5.4.3         | Apache-2.0             |
| echarts                    | 5.5.0         | Apache-2.0             |
| echarts                    | 5.5.1         | Apache-2.0             |
| vue-i18n                   | 9.13.1        | MIT                    |
| vue-i18n                   | 9.5.0         | MIT                    |
| vue-i18n                   | 9.2.2         | MIT                    |
| lodash-es                  | 4.17.21       | MIT                    |
| bignumber.js               | 9.1.2         | MIT                    |
| big.js                     | 6.2.1         | MIT                    |
| codemirror                 | 6.0.1         | MIT                    |
| codemirror                 | 5.56.16       | MIT                    |
| codemirror                 | 5.49.2        | MIT                    |
| xml2js                     | 0.6.2         | MIT                    |
| animate.css                | 4.1.1         | MIT                    |
| @antv/x6                   | 2.18.1        | MIT                    |
| mitt                       | 3.0.0         | MIT                    |
| validator                  | 13.9.0        | MIT                    |
| vxe-table                  | 4.7.78        | MIT                    |
| vxe-table                  | 4.3.12-beta.2 | MIT                    |
| xlsx                       | 0.18.5        | Apache-2.0             |
| bpmn-js                    | 13.1.0        | bpmn.io许可证          |
| @iconify/vue               | 4.1.1         | MIT                    |

